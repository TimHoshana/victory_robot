#include "Ultrasonic.h"

Ultrasonic::Ultrasonic(const uint8_t trig_pin, const uint8_t echo_pin){
  _trig_pin = trig_pin;
  _echo_pin = echo_pin;
}
void Ultrasonic::setup(){
  pinMode(_echo_pin, INPUT);
  pinMode(_trig_pin, OUTPUT);
  
  digitalWrite(_trig_pin, LOW);
}


void Ultrasonic:: distanceCheck() {
    digitalWrite(_trig_pin, LOW);
    delayMicroseconds(2);
    digitalWrite(_trig_pin, HIGH);
    delayMicroseconds(10);
    digitalWrite(_trig_pin, LOW);
    timing = pulseIn(_echo_pin, HIGH, 2000);
    _distance_mm = timing != 0 ? (timing * 3.4) / 2 : 2600;
}