#pragma once
#include <Arduino.h>
#include <QTRSensors.h>
#include <array>


const uint8_t SensorCount = 8;

class QTR {

    private:
    uint8_t _linePosition[SensorCount];
    uint8_t _qtrSensor[SensorCount];
    uint8_t _qtrLed;
    QTRSensors qtr;
    uint16_t sensorValues[SensorCount];
    public:

    uint16_t _qrtMax[SensorCount];
    uint16_t _qrtMin[SensorCount];

    QTR(const uint8_t qtrSensors[], const uint16_t qrtMax_[], const uint16_t qrtMin_[], uint8_t qtrLed);
    std::array<uint8_t, SensorCount> linePosition() const;
    void calibration();
    void setup();
    void lineDetaction();
};