#include <Arduino.h>

class Mode1{
    public:
    static void setup();
    static void loopAction();
    static void loopChecks();
    static void modeEnd();
};